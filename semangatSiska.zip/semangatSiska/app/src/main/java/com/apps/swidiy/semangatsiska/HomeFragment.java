package com.apps.swidiy.semangatsiska;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.LinearLayout;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {

    private PostingAdapter adapter;
    private ArrayList<Posting> postings = new ArrayList<>();


    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        addData();

        //recyclerView = (RecyclerView)findViewByID(R.id.recycler_view);
        //adapter = new PostingAdapter(postings);
       // RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(HomeFragment .this);
        //recyclerView.setLayoutManager(layoutManager);
        //recyclerView.setAdapter(adapter);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
        RecyclerView recyclerView = view.findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(linearLayoutManager);
        PostingAdapter adapter = new PostingAdapter(getContext(), postings);
        recyclerView.setAdapter(adapter);
        return view;
    }

    void addData(){
        postings = new ArrayList<>();
        postings.add(new Posting("Dimas Maulana", "1414370309"));
        postings.add(new Posting("Fadly Yonk", "1214234560"));
        postings.add(new Posting("Ariyandi Nugraha", "1214230345"));
        postings.add(new Posting("Aham Siswana", "1214378098"));
    }

    /*@Override
    protected void onCreat(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);*/

}
